import numpy as np
import random
import sys

def get_hex(value, fmt="{:08x}"):
    """Convert a value to hexadecimal format with zero-padding."""
    if value < 0:
        c = 2**32 + value  # 32-bit wrap-around
    else:
        c = value
    return fmt.format(int(c))

def dump_coe(filename, x):
    """Write data to a .coe file for FFT processing."""
    with open(filename, "w") as f:
        f.write("; Hex equivalent of test input for FFT 32-bit\n")
        f.write("memory_initialization_radix=16;\n")  # Corrected radix for 32-bit
        f.write("memory_initialization_vector=\n")
        for val in x[:-1]:
            dr = get_hex(val.real * (2**16))
            di = get_hex(val.imag * (2**16))
            f.write(di + dr + ",\n")
        val = x[-1]
        dr = get_hex(val.real * (2**16))
        di = get_hex(val.imag * (2**16))
        f.write(di + dr + ";\n")

def dump_mem(filename, x):
    """Write data to a .mem file in hexadecimal format."""
    with open(filename, "w") as f:
        for val in x:
            dr = get_hex(val.real * (2**16))
            di = get_hex(val.imag * (2**16))
            f.write(di + dr + "\n")

if __name__ == "__main__":
    N = 512  # Adjustable FFT size
    np.random.seed(0)  # Ensure reproducibility
    
    # Generate random complex numbers
    data = np.array([(np.random.randn() + 1j * np.random.randn()) for _ in range(N)])
    result = np.fft.fft(data)
    
    # Save data in text format for debugging
    np.savetxt("inp_cpp.txt", np.column_stack((data.real, data.imag)), fmt="%f %f")
    np.savetxt("out_cpp.txt", np.column_stack((result.real, result.imag)), fmt="%f %f")
    
    # Save data in hexadecimal format
    dump_mem("inp_hex.mem", data)
    dump_mem("out_hex.mem", result)
    dump_coe("inp_hex.coe", data)
    dump_coe("out_hex.coe", result)
