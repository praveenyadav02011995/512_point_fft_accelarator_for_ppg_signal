clear all;
close all;
clc

% Read the CSV file
data = readmatrix('s10_run.csv');

% Extract the second column
extracted_data = data(:, 2);

% Downsample the data by selecting the first 512 rows
downsampled_data = extracted_data(1:4:2048);

% Find the maximum number in the downsampled data
maxNumber = max(downsampled_data);

% Display the maximum number
fprintf('The maximum number in the downsampled data is: %f\n', maxNumber);

% Normalize the data by dividing by the maximum number
normalized_data = downsampled_data / maxNumber;

% Save the normalized data to a new TXT file
writematrix(normalized_data, 'normalized_data.txt');
disp('Normalization complete. Data saved to normalized_data.txt');

% Select the first 512 points for FFT
L = 512;
if length(normalized_data) < L
    error('Not enough data points after downsampling for 512-point FFT.');
end
signal = normalized_data(1:L);

% Perform 512-point FFT
fft_result = fft(signal, L);

% Compute the two-sided spectrum P2 and then the single-sided spectrum P1
P2 = abs(fft_result / L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2 * P1(2:end-1);

% Convert P1 to dB
P1_dB = 10 * log10(P1);

% Define the frequency domain f
Fs = 125;  % The sampling rate of the PPG signal is 125 Hz
f = Fs * (0:(L/2)) / L;

% Plot the single-sided amplitude spectrum in dB
figure;
plot(f, P1_dB)
title('Single-Sided Amplitude Spectrum of the PPG Data (dB)')
xlabel('Frequency (Hz)')
ylabel('|P1(f)| (dB)')

disp('512-point FFT computation complete.');

% Apply fixed-point operation on the FFT result
wordLength = 24;
fractionLength = 12;
fixed_point_fft_result = fi(fft_result, true, wordLength, fractionLength);

% Convert fixed-point FFT result to double for saving to file
fixed_point_fft_result_double = double(fixed_point_fft_result);

% Save the fixed-point FFT result to a TXT file
writematrix(fixed_point_fft_result_double, 'fft_result.txt', 'Delimiter', 'tab');
disp('FFT result saved to fft_result.txt.');

% Load data_out, inp_cpp, and out_cpp.txt for error analysis
FFT_output = readmatrix('data_out.txt');
input = readmatrix('inp_cpp.txt');
MATLAB_FFT_output = readmatrix('out_cpp.txt');

% Ensure data_out and out_cpp vectors are the same length
if length(FFT_output) ~= length(MATLAB_FFT_output)
    error('data_out and out_cpp must be of the same length.');
end

% Compute the error between the two results
error = FFT_output - MATLAB_FFT_output;

% Plot the error
figure;
plot(error)
title('Error between HLS\_FFT\_output and MATLAB\_FFT\_output')
xlabel('Sample Index')
ylabel('Error')
disp('Error computation and plot complete.');

% Save data_out, inp_cpp, and out_cpp to a CSV file
output_filename = 'ppg1.csv';
PPG1 = table(input, FFT_output, MATLAB_FFT_output);
writetable(PPG1, output_filename);
disp(['Data saved to ', output_filename]);
