#include "512fft.h"
#include "512fftvalues.h"
//#include <iostream> // Enable for debugging if necessary

using namespace std;

void bitreverse(data_comp data_IN[N], data_comp data_OUT[N]) {
    bitreversal_label1: for (int i = 0; i < N; i++) {
#pragma HLS PIPELINE
        int index = rev_512[i];
        data_OUT[i] = data_IN[index];
    }
}

void FFT0(int FFT_stage, int pass_check, int index_shift, int pass_shift, data_comp data_IN[N], data_comp data_OUT[N]) {
#pragma HLS DATAFLOW




    int butterfly_span = 0, butterfly_pass = 0;

  FFT_label1:  for (int i = 0; i < N / 2; i++) {
#pragma HLS PIPELINE
        int index = butterfly_span << index_shift;
        int Ulimit = butterfly_span + (butterfly_pass << pass_shift);
        int Llimit = Ulimit + FFT_stage;

        // Use double precision for intermediate calculations
        data_comp Product = W[index] * data_IN[Llimit];
        data_OUT[Llimit] = data_IN[Ulimit] - Product;
        data_OUT[Ulimit] = data_IN[Ulimit] + Product;

        if (butterfly_span < FFT_stage - 1) {
            butterfly_span++;
        } else if (butterfly_pass < pass_check - 1) {
            butterfly_span = 0;
            butterfly_pass++;
        } else {
            butterfly_span = 0;
            butterfly_pass = 0;
        }
    }
}

void FFT(data_comp data_IN[N], data_comp data_OUT[N]) {
#pragma HLS INTERFACE s_axilite port=data_OUT
#pragma HLS INTERFACE s_axilite port=data_IN
#pragma HLS INTERFACE s_axilite port=return

    static data_comp data_OUT0[N];
    static data_comp data_OUT1[N];
    static data_comp data_OUT2[N];
    static data_comp data_OUT3[N];
    static data_comp data_OUT4[N];
    static data_comp data_OUT5[N];
    static data_comp data_OUT6[N];
    static data_comp data_OUT7[N];
    static data_comp data_OUT8[N];

    static data_comp xin[N];
    static data_comp xout[N];

    for (int i = 0; i < N; i++) {
        xin[i] = data_IN[i];
    }

    bitreverse(xin, data_OUT0);

    FFT0(1, 256, 8, 1, data_OUT0, data_OUT1);
    FFT0(2, 128, 7, 2, data_OUT1, data_OUT2);
    FFT0(4, 64, 6, 3, data_OUT2, data_OUT3);
    FFT0(8, 32, 5, 4, data_OUT3, data_OUT4);
    FFT0(16, 16, 4, 5, data_OUT4, data_OUT5);
    FFT0(32, 8, 3, 6, data_OUT5, data_OUT6);
    FFT0(64, 4, 2, 7, data_OUT6, data_OUT7);
    FFT0(128, 2, 1, 8, data_OUT7, data_OUT8);
    FFT0(256, 1, 0, 9, data_OUT8, xout);

    for (int i = 0; i < N; i++) {
        data_OUT[i] = xout[i];
    }

    // Debug: Print intermediate results
    // Uncomment to debug and check intermediate values
    // for (int i = 0; i < N; i++) {
    //     cout << "data_OUT[" << i << "]: " << data_OUT[i] << endl;
    // }
}
