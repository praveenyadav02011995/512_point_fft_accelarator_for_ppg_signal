#ifndef __512FFT_H__
#define __512FFT_H__

#include <math.h>
#include <complex>
#include <ap_fixed.h>

using namespace std;
#define N 512

// Increase the fractional precision to achieve better tolerance
typedef ap_fixed<32, 16> data_t;  // 64 bits total, 16 bits for integer part
typedef complex<data_t> data_comp;

#include "512fftvalues.h"
void FFT(data_comp data_IN[N], data_comp data_OUT[N]);

#endif
