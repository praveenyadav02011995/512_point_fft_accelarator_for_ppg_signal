#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <complex>
#include "512fft.h"

#define TOL 0.001
#define NORM(x) ((x) * (x)).real()

int main()
{
    int result = 0;
    for(int z = 0; z < 2; z++) {
        data_comp data_in[N];
        data_comp data_out[N];
        data_comp exp_out[N];
        std::ifstream FFTfileIN("inp_cpp.txt");  // Reading input to the FFT
        std::ifstream FFTfileOUT("out_cpp.txt"); // Expected FFT
        if (FFTfileIN.fail() || FFTfileOUT.fail()) {
            std::cerr << "Failed to open file." << std::endl;
            exit(-1);
        }
        data_t temp1, temp2, temp3, temp4;

        for(int i = 0; i < N; i++) {
            FFTfileIN >> temp1 >> temp2;
            data_in[i] = data_comp(temp1, temp2);
        }
        FFTfileIN.close();

        FFT(data_in, data_out);

        // Save data_out to a file
        std::ofstream outputFile("data_out.txt");
        if (!outputFile) {
            std::cerr << "Failed to open output file." << std::endl;
            exit(-1);
        }
        for(int i = 0; i < N; i++) {
            outputFile << data_out[i].real() << " " << data_out[i].imag() << std::endl;
        }
        outputFile.close();

        for(int j = 0; j < N; j++) {
            FFTfileOUT >> temp3 >> std::ws >> temp4;
            exp_out[j] = data_comp(temp3, temp4);
        }
        FFTfileOUT.close();

        for(int k = 0; k < N; k++) {
            data_t n = NORM(exp_out[k] - data_out[k]);
            if (n > TOL) {
                result++;
                // Debug: Print mismatched values
                std::cout << "Mismatch at index " << k << ": Expected " << exp_out[k] << ", Got " << data_out[k] << ", Norm: " << n << std::endl;
            }
        }
    }
    if (result == 0) {
        std::cout << "PASS" << std::endl;
    } else {
        std::cout << "FAIL: " << result << " errors" << std::endl;
    }
    return result;
}
