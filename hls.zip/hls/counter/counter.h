#ifndef COUNTER_H
#define COUNTER_H

int counter();  // Declaration of the counter function

#endif  // COUNTER_H
